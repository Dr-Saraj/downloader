# Visited: https://www.youtube.com/c/4vafa4
**Time:** Wed May  6 17:19:39 UTC 2026

## Screenshot
![Screenshot](./screenshot.png)

## Raw HTML
[page.html](./page.html)

## Downloaded Media (5 files)
## Downloaded Media Files

- [favicon.ico](./media/favicon.ico) (13 KB)
![favicon_144x144.png](./media/favicon_144x144.png)
![favicon_32x32.png](./media/favicon_32x32.png)
![favicon_48x48.png](./media/favicon_48x48.png)
![favicon_96x96.png](./media/favicon_96x96.png)

## Other Links
- [/](/)
- [//fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=YouTube+Sans:wght@300..900&display=swap](//fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&family=YouTube+Sans:wght@300..900&display=swap)
- [/manifest.webmanifest](/manifest.webmanifest)
- [/new](/new)
- [/t/contact_us/](/t/contact_us/)
- [/t/privacy](/t/privacy)
- [/t/terms](/t/terms)
- [android-app://com.google.android.youtube/http/www.youtube.com/channel/UC7bPCZOmR8xc_8UjBgP_8pg](android-app://com.google.android.youtube/http/www.youtube.com/channel/UC7bPCZOmR8xc_8UjBgP_8pg)
- [https://accounts.google.com/ServiceLogin?service=youtube&amp;uilel=3&amp;passive=true&amp;continue=https%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26hl%3Den%26next%3D%252Fsignin_passive%26feature%3Dpassive&amp;hl=en](https://accounts.google.com/ServiceLogin?service=youtube&amp;uilel=3&amp;passive=true&amp;continue=https%3A%2F%2Fwww.youtube.com%2Fsignin%3Faction_handle_signin%3Dtrue%26app%3Ddesktop%26hl%3Den%26next%3D%252Fsignin_passive%26feature%3Dpassive&amp;hl=en)
- [https://developers.google.com/youtube](https://developers.google.com/youtube)
- [https://m.youtube.com/c/4vafa4](https://m.youtube.com/c/4vafa4)
- [https://tv.youtube.com/learn/nflsundayticket](https://tv.youtube.com/learn/nflsundayticket)
- [https://www.youtube.com/about/](https://www.youtube.com/about/)
- [https://www.youtube.com/about/copyright/](https://www.youtube.com/about/copyright/)
- [https://www.youtube.com/about/policies/](https://www.youtube.com/about/policies/)
- [https://www.youtube.com/about/press/](https://www.youtube.com/about/press/)
- [https://www.youtube.com/ads/](https://www.youtube.com/ads/)
- [https://www.youtube.com/channel/UC7bPCZOmR8xc_8UjBgP_8pg](https://www.youtube.com/channel/UC7bPCZOmR8xc_8UjBgP_8pg)
- [https://www.youtube.com/creators/](https://www.youtube.com/creators/)
- [https://www.youtube.com/feeds/videos.xml?channel_id=UC7bPCZOmR8xc_8UjBgP_8pg](https://www.youtube.com/feeds/videos.xml?channel_id=UC7bPCZOmR8xc_8UjBgP_8pg)
- [https://www.youtube.com/howyoutubeworks?utm_campaign=ytgen&amp;utm_source=ythp&amp;utm_medium=LeftNav&amp;utm_content=txt&amp;u=https%3A%2F%2Fwww.youtube.com%2Fhowyoutubeworks%3Futm_source%3Dythp%26utm_medium%3DLeftNav%26utm_campaign%3Dytgen](https://www.youtube.com/howyoutubeworks?utm_campaign=ytgen&amp;utm_source=ythp&amp;utm_medium=LeftNav&amp;utm_content=txt&amp;u=https%3A%2F%2Fwww.youtube.com%2Fhowyoutubeworks%3Futm_source%3Dythp%26utm_medium%3DLeftNav%26utm_campaign%3Dytgen)
- [https://www.youtube.com/opensearch?locale=en_US](https://www.youtube.com/opensearch?locale=en_US)
- [https://www.youtube.com/s/_/ytmainappweb/_/js/k=ytmainappweb.kevlar_base.en_US.spofGxkI9nw.es5.O/am=AAAAAAEAgQQ/d=1/rs=AGKMywGMC3V0qp6i7ZD8pciFHAXeyn_ZIw/m=kevlar_base_module,kevlar_main_module,kevlar_base_sync_mod_chunk](https://www.youtube.com/s/_/ytmainappweb/_/js/k=ytmainappweb.kevlar_base.en_US.spofGxkI9nw.es5.O/am=AAAAAAEAgQQ/d=1/rs=AGKMywGMC3V0qp6i7ZD8pciFHAXeyn_ZIw/m=kevlar_base_module,kevlar_main_module,kevlar_base_sync_mod_chunk)
- [https://www.youtube.com/s/_/ytmainappweb/_/ss/k=ytmainappweb.kevlar_base.7lH-Jm86Zhg.L.X.O/am=AAAAAAECwQQ/d=0/rs=AGKMywHMnZ9h9O1JYVYqdE_ykiEwDQeA0w](https://www.youtube.com/s/_/ytmainappweb/_/ss/k=ytmainappweb.kevlar_base.7lH-Jm86Zhg.L.X.O/am=AAAAAAECwQQ/d=0/rs=AGKMywHMnZ9h9O1JYVYqdE_ykiEwDQeA0w)
- [https://www.youtube.com/s/desktop/2279fdfc/cssbin/www-main-desktop-watch-page-skeleton.css](https://www.youtube.com/s/desktop/2279fdfc/cssbin/www-main-desktop-watch-page-skeleton.css)
- [https://www.youtube.com/s/desktop/2279fdfc/cssbin/www-onepick.css](https://www.youtube.com/s/desktop/2279fdfc/cssbin/www-onepick.css)
- [https://www.youtube.com/s/desktop/2279fdfc/jsbin/fetch-polyfill.vflset/fetch-polyfill.js](https://www.youtube.com/s/desktop/2279fdfc/jsbin/fetch-polyfill.vflset/fetch-polyfill.js)
- [https://www.youtube.com/s/desktop/2279fdfc/jsbin/intersection-observer.min.vflset/intersection-observer.min.js](https://www.youtube.com/s/desktop/2279fdfc/jsbin/intersection-observer.min.vflset/intersection-observer.min.js)
- [https://www.youtube.com/s/desktop/2279fdfc/jsbin/network.vflset/network.js](https://www.youtube.com/s/desktop/2279fdfc/jsbin/network.vflset/network.js)
- [https://www.youtube.com/s/desktop/2279fdfc/jsbin/scheduler.vflset/scheduler.js](https://www.youtube.com/s/desktop/2279fdfc/jsbin/scheduler.vflset/scheduler.js)
- [https://www.youtube.com/s/desktop/2279fdfc/jsbin/spf.vflset/spf.js](https://www.youtube.com/s/desktop/2279fdfc/jsbin/spf.vflset/spf.js)
- [https://www.youtube.com/s/desktop/2279fdfc/jsbin/web-animations-next-lite.min.vflset/web-animations-next-lite.min.js](https://www.youtube.com/s/desktop/2279fdfc/jsbin/web-animations-next-lite.min.vflset/web-animations-next-lite.min.js)
- [https://www.youtube.com/s/desktop/2279fdfc/jsbin/webcomponents-all-noPatch.vflset/webcomponents-all-noPatch.js](https://www.youtube.com/s/desktop/2279fdfc/jsbin/webcomponents-all-noPatch.vflset/webcomponents-all-noPatch.js)
- [https://www.youtube.com/s/desktop/2279fdfc/jsbin/www-i18n-constants-en_US.vflset/www-i18n-constants.js](https://www.youtube.com/s/desktop/2279fdfc/jsbin/www-i18n-constants-en_US.vflset/www-i18n-constants.js)
- [https://yt3.googleusercontent.com/OnCGzSVhDt-N6T3QeYbmGjGW5jkFP82ojTgI0HzFziTckqkex2VGowKSrIOFfdDMBpEhmJRNSA=s900-c-k-c0x00ffffff-no-rj](https://yt3.googleusercontent.com/OnCGzSVhDt-N6T3QeYbmGjGW5jkFP82ojTgI0HzFziTckqkex2VGowKSrIOFfdDMBpEhmJRNSA=s900-c-k-c0x00ffffff-no-rj)
- [ios-app://544007664/vnd.youtube/www.youtube.com/channel/UC7bPCZOmR8xc_8UjBgP_8pg](ios-app://544007664/vnd.youtube/www.youtube.com/channel/UC7bPCZOmR8xc_8UjBgP_8pg)

## Stats
- Links: 41
- Media: 5
